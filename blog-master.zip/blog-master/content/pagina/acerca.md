---
title: "Acerca"
date: 2018-07-08T04:36:24-04:00
draft: true
#tags: ["tag1", "tag2"]
description: "De qué va este blog personal"
cover: https://a.geek.cl/img/logo-@ac-cuadrado.png
lua:
  image:
    url: "/img/logo-@ac-cuadrado.png"
    width: 250
    height: 250
  author: "Arturo C."
---
Hola, soy Arturo Castro y este es mi blog personal.

Como en todo blog personal acá iré plasmando mis pensamientos u/o opiniones respecto a diferentes temas. Estos temas pueden ir desde la energía atómica hasta el chocolate que me compré ayer y no me gustó.

Este espacio lo pensé como un reemplazo de las redes sociales que abandoné. Facebook e Instagram han sidos reemplazados por este blog, mis imágenes y pensamientos que desée compartir voy a publicarlas por acá.

Si deseas interactuar conmigo, me puedes encontrar en mi email o en twitter, en ambos lugares podemos intercambiar ideas.
