---
title: "Maldito Libre Mercado"
date: 2019-09-29T06:44:00Z
draft: false
tags: ["afp", "opinion", "libre mercado"]
description: "Maldito Libre Mercado"
cover: https://a.geek.cl/img/09/hanson-lu-sq5P00L7lXc-unsplash.jpg
lua:
  image:
    url: "/img/09/hanson-lu-sq5P00L7lXc-unsplash.jpg"
    width: 320
    height: 214
  author: "Arturo C."
---
![Maldito Libre Mercado](/img/09/hanson-lu-sq5P00L7lXc-unsplash.jpg#c)<br \>
<cite>Fotografía Por ~ [Hanson Lu](https://unsplash.com/@hansonluu)</cite>

Me apesta y me desanima lo desprotegidos que estamos en general, no sólo en Chile, ante el [Libre Mercado](https://es.wikipedia.org/wiki/Mercado_libre).

Estoy convencido que es una utopía *dejar libre* este maldito sistema comercial que nos rige y nos hace una pieza más de su engranaje.


