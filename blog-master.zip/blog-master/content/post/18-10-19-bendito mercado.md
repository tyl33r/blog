---
title: "18-10-19 Bendito Mercado"
date: 2020-02-14T06:44:00Z
draft: false
tags: ["afp", "opinion", "libre mercado"]
description: "Bendito Mercado"
cover: https://a.geek.cl/img/02/equidad-bendito-mercado.jpeg
lua:
  image:
    url: "/img/02/equidad-bendito-mercado.jpeg"
    width: 357
    height: 500
  author: "Arturo C."
---
![Equidad Bendito Mercado](/img/02/equidad-bendito-mercado.jpeg#c)<br \>
<cite>Fotografía Por ~ [Wesley Tingey](https://unsplash.com/@wesleyphotography)</cite>

Se rebalsó el vaso, el [Maldito Libre Mercado](https://a.geek.cl/maldito-libre-mercado/) tiene sus días contados. Para los *“afortunados”* de siempre es una catástrofe, para el resto, la gran mayoría, se instala la esperanza de mayor equidad y justicia social. 

Creo que no es utópico instaurar un sistema alimentado por los incentivos necesarios para generar progreso y equidad, pero que también se le fiscalice con mano dura. Ojalá un día, podamos llegar a pensar que estamos bajo el alero de un *Bendito Mercado*.


