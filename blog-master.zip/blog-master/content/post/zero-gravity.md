---
title: "Zero Gravity"
date: 2018-07-29T15:45:15-04:00
draft: false
tags: ["imagen", "tumbrl", "fotografía"]
description: "Zero Gravity - Gravedad Cero"
cover: https://a.geek.cl/img/07/tumblr_noxdqy8A111rtfluuo1_1280.jpg
lua:
  image:
    url: "/img/07/tumblr_noxdqy8A111rtfluuo1_1280.jpg"
    width: 753
    height: 500
  author: "Arturo C."
---

![Zero Gravity](/img/07/tumblr_noxdqy8A111rtfluuo1_1280.jpg#c)<br \>
<cite>Por ~ [Jake Raynor](http://jakeraynor.tumblr.com/post/119882598966/zero-gravity)</cite>

